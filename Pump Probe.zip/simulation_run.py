from Functions import generate_zigzag_coords, haldane_zigzag_probe, haldane_zigzag_pump, runge_kutta_step_probe, runge_kutta_step_pump, excite_chunk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from variables import n,m,c,cNN_mag,phi,M1,M2,chunk,g,mag,timesteps,dt
import os
import time

start_time = time.time()

print('g=', g)
print('mag=' , mag)
print('total Timesteps= ', timesteps)
print(' Simulation in progress ....')

psi_pump = excite_chunk(n, m, chunk, mag=mag)

# psi_pump[220] = 0
# psi_pump[221] = 0
# psi_pump[222] = 0
# psi_pump[223] = 0


psi_probe = np.zeros(2 * n * m, dtype=complex)
psi_probe[171] = 0.1
psi_probe[173] = -0.1
psi_probe[175] = 0.1
psi_probe[177] = -0.1


evolution_pump = []
evolution_probe = []
evolution_self = []
for _ in range(timesteps):
    psi_pump = runge_kutta_step_pump(psi_pump, dt, n, m, c, cNN_mag, phi, M1, M2, chunk, g)
    evolution_pump.append(np.abs(psi_pump)**2)
    psi_probe = runge_kutta_step_probe(psi_pump, psi_probe, dt, n, m, c, cNN_mag, phi, M1, M2, chunk, g)
    evolution_probe.append(np.abs(psi_probe)**2)


# save data
save_path = "C:/Users/Unbekannter Nutzer/Desktop/codes/data"
os.makedirs(save_path, exist_ok=True)

# Full file path
file_path = os.path.join(save_path, f"evolution_data_g={g}_mag={mag}.npz")

# Save the data
np.savez(file_path, 
         evolution_pump=np.array(evolution_pump), 
         evolution_probe=np.array(evolution_probe))

end_time = time.time()
elapsed = end_time - start_time

# Format as hh:mm:ss
hours, rem = divmod(elapsed, 3600)
minutes, seconds = divmod(rem, 60)
print(f"\n✅ Simulation completed in {int(hours):02}:{int(minutes):02}:{int(seconds):02}")