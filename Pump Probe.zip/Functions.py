import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation


def generate_zigzag_coords(n, m):
    """
    Returns X, Y coordinate arrays for zigzag nanoribbon sites (interleaved A and B).
    A-sites at even indices, B-sites at odd indices.
    """
    # Lattice vectors
    a1 = np.array([1.5,  np.sqrt(3)/2])
    a2 = np.array([1.5, -np.sqrt(3)/2])
    delta = np.array([[0, 0], [1, 0]])  # A and B sublattice offsets

    # Generate grid of unit cells
    IX, IY = np.meshgrid(np.arange(n), np.arange(m))
    IX = IX.flatten()
    IY = IY.flatten()
    N_uc = len(IX)
    N = 2 * N_uc

    # Allocate coordinate arrays
    X = np.zeros(N)
    Y = np.zeros(N)

    # A sublattice positions
    A_x = IX * a1[0] + IY * a2[0] + delta[0, 0]
    A_y = IX * a1[1] + IY * a2[1] + delta[0, 1]

    # B sublattice positions
    B_x = IX * a1[0] + IY * a2[0] + delta[1, 0]
    B_y = IX * a1[1] + IY * a2[1] + delta[1, 1]

    # Interleave A and B into single arrays
    X[0::2] = A_x
    Y[0::2] = A_y
    X[1::2] = B_x
    Y[1::2] = B_y

    return X, Y

#--------------------------------------------------#
import numpy as np

def haldane_zigzag_pump(n, m, c, cNN_mag, phi, M1, M2, chunk, g, psi=None, nonlinear_sites=None):
    """
    Generate the Haldane tight-binding Hamiltonian on a zigzag nanoribbon,
    with optional Kerr nonlinearity from psi if provided.
    """
    N = 2 * n * m
    H = np.zeros((N, N), dtype=complex)
    cNN = cNN_mag * np.exp(1j * phi)

    # Precompute indices for all A and B sites
    indices_A = 2 * (np.arange(m) * n + np.arange(n)[:, None])  # A sites
    indices_B = indices_A + 1  # B sites

    # Flatten the indices for easy access
    indices_A_flat = indices_A.flatten()
    indices_B_flat = indices_B.flatten()

    # On-site mass terms (for all sites at once)
    if psi is not None:
        H[indices_A_flat, indices_A_flat] = M1 / 2 + g * np.abs(psi[indices_A_flat])**2
        H[indices_B_flat, indices_B_flat] = -M1 / 2 - g * np.abs(psi[indices_B_flat])**2
    else:
        H[indices_A_flat, indices_A_flat] = M1 / 2
        H[indices_B_flat, indices_B_flat] = -M1 / 2

    # Nearest-neighbor hopping (A-B)
    shift_right = np.roll(indices_A_flat, shift=-1)  # Right shift for A sites
    shift_up = np.roll(indices_A_flat, shift=-n)    # Upward shift for A sites

    # Ensure valid right and up indices (avoid out-of-bounds errors)
    valid_right = shift_right < N
    valid_up = shift_up < N
    
    # Properly index Hamiltonian using 1D row-column indices
    row_right = indices_B_flat[valid_right]
    col_right = shift_right[valid_right]
    H[row_right, col_right] = -c

    row_up = indices_B_flat[valid_up]
    col_up = shift_up[valid_up]
    H[row_up, col_up] = -c

    # Connect A and B sites (direct hopping)
    H[indices_A_flat, indices_B_flat] = -c

    # Next-nearest-neighbor hopping (A-A and B-B)
    a_nn_offsets = np.array([[1, 0], [-1, 1], [0, -1]])
    b_nn_offsets = np.array([[-1, 0], [1, -1], [0, 1]])

    # For A sites (loop through offsets and compute new A-A hopping terms)
    for dx, dy in a_nn_offsets:
        shift_A_nn = np.roll(indices_A_flat, shift=(dx * n + dy))  # Apply the shift
        valid_A_nn = (shift_A_nn >= 0) & (shift_A_nn < N)
        row_A_nn = indices_A_flat[valid_A_nn]
        col_A_nn = shift_A_nn[valid_A_nn]
        H[row_A_nn, col_A_nn] = -cNN

    # For B sites (loop through offsets and compute new B-B hopping terms)
    for dx, dy in b_nn_offsets:
        shift_B_nn = np.roll(indices_B_flat, shift=(dx * n + dy))  # Apply the shift
        valid_B_nn = (shift_B_nn >= 0) & (shift_B_nn < N)
        row_B_nn = indices_B_flat[valid_B_nn]
        col_B_nn = shift_B_nn[valid_B_nn]
        H[row_B_nn, col_B_nn] = -cNN

    # Hermitian symmetrization
    H = H + H.conj().T

    return H



def haldane_zigzag_probe(n, m, c, cNN_mag, phi, M1, M2, chunk, g, psi=None, nonlinear_sites=None):
    """
    Generate the Haldane tight-binding Hamiltonian on a zigzag nanoribbon,
    with optional Kerr nonlinearity from psi if provided.
    """
    N = 2 * n * m
    H = np.zeros((N, N), dtype=complex)
    cNN = cNN_mag * np.exp(1j * phi)

    # Precompute indices for all A and B sites
    indices_A = 2 * (np.arange(m) * n + np.arange(n)[:, None])  # A sites
    indices_B = indices_A + 1  # B sites

    # Flatten the indices for easy access
    indices_A_flat = indices_A.flatten()
    indices_B_flat = indices_B.flatten()

    # On-site mass terms (for all sites at once)
    if psi is not None:
        H[indices_A_flat, indices_A_flat] = M1 / 2 + g * np.abs(psi[indices_A_flat])**2
        H[indices_B_flat, indices_B_flat] = -M1 / 2 - g * np.abs(psi[indices_B_flat])**2
    else:
        H[indices_A_flat, indices_A_flat] = M1 / 2
        H[indices_B_flat, indices_B_flat] = -M1 / 2

    # Nearest-neighbor hopping (A-B)
    shift_right = np.roll(indices_A_flat, shift=-1)  # Right shift for A sites
    shift_up = np.roll(indices_A_flat, shift=-n)    # Upward shift for A sites

    # Ensure valid right and up indices (avoid out-of-bounds errors)
    valid_right = shift_right < N
    valid_up = shift_up < N

    # Properly index Hamiltonian using 1D row-column indices
    # For rightward hopping (A-B)
    row_right = indices_B_flat[valid_right]
    col_right = shift_right[valid_right]
    H[row_right, col_right] = -c

    # For upward hopping (A-B)
    row_up = indices_B_flat[valid_up]
    col_up = shift_up[valid_up]
    H[row_up, col_up] = -c

    # Connect A and B sites (direct hopping)
    H[indices_A_flat, indices_B_flat] = -c

    # Next-nearest-neighbor hopping (A-A and B-B)
    a_nn_offsets = np.array([[1, 0], [-1, 1], [0, -1]])
    b_nn_offsets = np.array([[-1, 0], [1, -1], [0, 1]])

    # For A sites (loop through offsets and compute new A-A hopping terms)
    for dx, dy in a_nn_offsets:
        shift_A_nn = np.roll(indices_A_flat, shift=(dx * n + dy))  # Apply the shift
        valid_A_nn = (shift_A_nn >= 0) & (shift_A_nn < N)
        row_A_nn = indices_A_flat[valid_A_nn]
        col_A_nn = shift_A_nn[valid_A_nn]
        H[row_A_nn, col_A_nn] = -cNN

    # For B sites (loop through offsets and compute new B-B hopping terms)
    for dx, dy in b_nn_offsets:
        shift_B_nn = np.roll(indices_B_flat, shift=(dx * n + dy))  # Apply the shift
        valid_B_nn = (shift_B_nn >= 0) & (shift_B_nn < N)
        row_B_nn = indices_B_flat[valid_B_nn]
        col_B_nn = shift_B_nn[valid_B_nn]
        H[row_B_nn, col_B_nn] = -cNN

    # Hermitian symmetrization
    H = H + H.conj().T

    return H


def excite_chunk(n, m, chunk, mag):
    """Returns an initial ψ with amplitude 1 in the central chunk (A and B), zeros elsewhere."""
    psi = np.zeros(2 * n * m, dtype=complex)
    for ix in range(n):
        for iy in range(m):
            if (n // 2 - chunk <= ix <= n // 2 + chunk) and (m // 2 - chunk <= iy <= m // 2 + chunk):
                a = 2 * (iy * n + ix)
                b = a + 1
                psi[a] = mag
                psi[b] = mag
    return psi




def runge_kutta_step_pump(psi, dt, n, m, c, cNN_mag, phi, M1, M2, chunk, g):
    def H_total(psi):
        return haldane_zigzag_pump(n, m, c, cNN_mag, phi, M1, M2, chunk, psi=psi, g=g)

    H = H_total(psi)
    k1 = -1j * H @ psi
    k2 = -1j * H @ (psi + 0.5 * dt * k1)
    k3 = -1j * H @ (psi + 0.5 * dt * k2)
    k4 = -1j * H @ (psi + dt * k3)

    psi_new = psi + (dt / 6) * (k1 + 2*k2 + 2*k3 + k4)
    return psi_new


def runge_kutta_step_probe(psi_pump, psi_probe, dt, n, m, c, cNN_mag, phi, M1, M2, chunk, g):
    def H_total(psi_pump):
        return haldane_zigzag_probe(n, m, c, cNN_mag, phi, M1, M2, chunk, psi=psi_pump, g=g)

    H = H_total(psi_pump)
    k1 = -1j * H @ psi_probe
    k2 = -1j * H @ (psi_probe + 0.5 * dt * k1)
    k3 = -1j * H @ (psi_probe + 0.5 * dt * k2)
    k4 = -1j * H @ (psi_probe + dt * k3)

    psi_probe_new = psi_probe + (dt / 6) * (k1 + 2*k2 + 2*k3 + k4)
    return psi_probe_new



