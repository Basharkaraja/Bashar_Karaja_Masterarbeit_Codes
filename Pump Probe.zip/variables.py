import numpy as np

n, m = 20, 20        # lattice dimensions
c = 1.0              # NN hopping
cNN_mag = 0.1 * c    # NNN hopping magnitude
phi = -np.pi / 2      # NNN hopping phase
M1 = 0.1               # bulk mass
M2 = 0.1               # perturbed region mass
chunk = 5            # perturbation chunk size
g = 5                # Kerr strength
# Create Hamiltonian
mag = 2 # 0.5   #8#4  redo mag = 2 

timesteps = 100000  # maybe run more steps for a smooth plot
dt = 0.01